<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title inertia><?php echo e(config('app.name', 'Laravel')); ?></title>

	<!-- Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Arapey&family=BenchNine&family=Ubuntu:ital,wght@0,300;0,500;0,700;1,300;1,500;1,700&family=Unica+One&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link rel="stylesheet" href="<?php echo e(asset('build/assets/app.6280e941.css')); ?>">

	<!-- Scripts -->
	<?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>
	<?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
	<?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.jsx']); ?>
	<?php if (!isset($__inertiaSsr)) { $__inertiaSsr = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsr instanceof \Inertia\Ssr\Response) { echo $__inertiaSsr->head; } ?>
	<script src="https://cdn.tiny.cloud/1/nrms2yne5q1nccauaz54wz1q5yyoipm1skz62mnhweyyqk88/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>

</head>

<body class="font-sans antialiased">
	<?php if (!isset($__inertiaSsr)) { $__inertiaSsr = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsr instanceof \Inertia\Ssr\Response) { echo $__inertiaSsr->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
	<div id="modal-root"></div>
</body>

</html><?php /**PATH C:\laragon\www\fora-da-caixa\resources\views/app.blade.php ENDPATH**/ ?>